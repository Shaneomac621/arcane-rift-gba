# ARCANE RIFT — Game Boy Advance source

An original dark-fantasy card-battle game project for GBA. This repository contains source code and an automated build workflow; a ROM is only considered ready after the workflow compiles it and it is tested in an emulator.

## Current implementation
- Title screen, five-rival campaign map, deck workshop, and card codex
- 2,000 player life points and five rivals with rising life/attack values
- 12-card deck, three-card hand, mana cost system, repeated card plays per turn, and turn-based rival attacks
- Eight card types: Shadow Bolt, Rift Drake, Soul Spark, Abyss Fang, Void Dragon, Rift Titan, Dusk Ward, and Echo Wisp
- Healing, guard effect, deck shuffling/recycling, campaign rewards, shards, and unlock flags
- D-pad/A/B/START/SELECT controls designed for a GBA or emulator
- GitHub Actions build workflow that compiles, checks the output, and uploads `ARCANE_RIFT.gba` as an artifact

## Build
Requires devkitPro with the GBA development tools (`gba-dev`). Run `make` from the repository root. Expected output: `ARCANE_RIFT.gba`.

## Controls
- Title: **A** campaign map, **START** deck workshop, **SELECT** card codex
- Campaign map: **UP/DOWN** choose rival, **A** duel, **B** title
- Duel: **LEFT/RIGHT** select card, **A** play, **B** end turn, **SELECT** deck, **START** title
- Deck workshop: **UP/DOWN** browse, **B** return
- Result: **A** continue after victory / retry after defeat, **B** campaign map

## Build and testing status
This is a source project, not a precompiled ROM. The workflow must finish successfully and the resulting ROM must launch in RetroArch or mGBA before it can be called tested. Automated compilation is not the same as emulator playtesting.
